<?php
session_start();
include_once('server.php');
$message = "";
$id = $_GET['playerID'];
if ($id == ""){
header("location:http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/index.php");
exit();
}
if (isset($_POST['submit'])) {
	$playerID = $_POST['playerID'];
	$playerName = $_POST['playerName'];
	$playerSurname = $_POST['playerSurname'];

	$sql = "DELETE FROM players WHERE playerID = $playerID ";
	mysqli_query($db, $sql);
	header("location:http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/players.php");
	} 
	if(mysqli_connect_error()){
	$message1 = "<font color=red>Update Failed, Try again</font>";
	}
		
?>

<!DOCTYPE html>
<html>

<head>
	<title>Teams</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" media="screen" href="/prim/style.css">
	<meta charset="utf-8">
</head>

<body>
	<h2 class="headingtitle team">Teams List</h2>

	<div id="content_1" class="content">
		<?php echo $message; ?>
		<form method="post">
			<table width="420" height="106" border="0">
				<tr>
					<td align="center"><input name="playerID" type="text" readonly style="width:170px" placeholder="playerID" value="<?php include_once('server.php');
																																	echo $_GET['playerID'] ?>" id="playerID" /></td>
				</tr>
				<tr>
					<td align="center"><input name="playerSurname" type="text" readonly style="width:170px" placeholder="Team Name" id="playerSurname" value="<?php include_once('server.php');
																																	echo $_GET['playerSurname'] ?>" id="playerSurname"/></td>
				</tr>
				<tr>
					<td align="center"><input name="playerName" type="text" readonly style="width:170px" placeholder="Team Email" id="playerName" value="<?php include_once('server.php');
																																	echo $_GET['playerName'] ?>" id="playerName"/></td>
				</tr>
				<tr>
					<td align="center"><input name="submit" type="submit" value="Delete" /></td>
				</tr>
			</table>
		</form>
	</div>
</body>

</html>
