<?php
session_start();
include_once('server.php');

$message = '';
$aTeam = '';
//if save the submit button is clicked ,information must be submitted
if (isset($_POST['submit'])) {
  $fixDate = $_POST['fixDate'];
  $fixTime = $_POST['fixTime'];
  $hTeam = $_POST['hTeam'];
  $aTeam = $_POST['aTeam'];
  $comp = $_POST['comp'];

  // error if user does not enter a Team Name
  if ($fixDate == "") {
    $message .= "<p><font color=red>Date should not be empty</font></p>";
  }
  // error if user does not enter a Team Email
  if ($fixTime == "") {
    $message .= "<p><font color=red>Fixture Time should not be empty</font></p>";
  } elseif ($hTeam == "") {
    $message .= "<p><font color=red>Home Team should not be empty</font></p>";
  } elseif ($aTeam == "") {
    $message .= "<p><font color=red>Away should not be empty</font></p>";
  } elseif ($comp == "") {
    $message .= "<p><font color=red>Competition should not be empty</font></p>";
  } else {
    $query = "SELECT * FROM fix WHERE hTeam='$hTeam'";
    $sql1 = mysqli_query($db, $query) or die(mysqli_connect_error());
    $result = mysqli_fetch_array($sql1);
    // an Email address can not be entered twice
    if ($result > 0) {
      $message .= "<p><font color=red>Sorry this Fixture already exists</font></p>";
    } else {
      $query = "INSERT INTO fix(fixDate, fixTime, hTeam, aTeam, comp) VALUES ('$fixDate', '$fixTime', '$hTeam', '$aTeam', '$comp')";
      mysqli_query($db, $query);
      // header('location : teametition.php'); //redirect to teametition page
    }
  }
}
?>

<!DOCTYPE html>
<html>

<head>
  <title>Fixtures</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" media="screen" href="style.css">
  <meta charset="utf-8">
  <!-- adding my menu starts here-->
  <div class="nav">
    <ul>
      <li><a href="competition.php/">Competitions</a></li>
      <li><a href="teams.php">Teams</a></li>
      <li><a href="fixtures.php">Fixtures</a></li>
      <li><a href="players.php/">Player lnfo</a></li>
      <li><a href="#">Player Fixtures</a></li>
      <li><a href="#">Reports</a></li>
    </ul>
  </div>
</head>
<!--css-->
<style>

</style>
<!--html startst here -->

<body>
  <h2 class="headingtitle team">Fixtures List</h2>
  <div class="error" style="text-align:center"><?php
                                                echo $message;
                                                ?></div>
  <!--table starts here-->
  <!--View Displays all data from 'Team' table
    -->
  <?php
  // connect to the database
  include_once('server.php');
  // get results from database
  $query = "SELECT * FROM fix";
  $result = mysqli_query($db, $query) or die(mysqli_connect_error());
  // display data in table
  echo "<table border='1' cellpadding='5' align='center'>";
  echo "<tr>
      <th>Fixture</th>
      <th>Date</th>
      <th>Time</th>
      <th>Home Team </th>
      <th>Away Team</th>
      <th>Competition</th>
      <th>Edit</th>
      <th>Delete</th>
    </tr>";
  // loop through results of database query, displaying them in the table
  while ($row = mysqli_fetch_array($result)) {
    // echo out the contents of each row into a table
    echo "<tr>";
    echo '<td>' . $row['fixID'] . '</td>';
    echo '<td>' . $row['fixDate'] . '</td>';
    echo '<td>' . $row['fixTime'] . '</td>';
    echo '<td>' . $row['hTeam'] . '</td>';
    echo '<td>' . $row['aTeam'] . '</td>';
    echo '<td>' . $row['comp'] . '</td>';
    ?>
    <td><a href="update_fixture.php?fixID=<?php echo $row['fixID'] ?>"><img src="images/edit.png" width="25" height="25" border="0" /></a></td>
    <td><a href="delete_fixture.php?fixID=<?php echo $row['fixID'].'&hTeam='. $row['hTeam'] .'&aTeam='. $row['aTeam']   ?>"><img src="images/delete.png" width="25" height="25" border="0" /></a></td>
  <?php
}
// close table>
echo "</table>";
?>
  <!--table ends here-->
  <!-- form starts here-->
  <!--connection to my database-->
  <form method="post">
    <div class="input">
      <label>Add Fixture</label>
      <!--<input type="text" name="add Competition">-->
    </div>
    <div class="input">
      <label>Date</label>
      <input type="text" name="fixDate" placeholder="YYYY-MM-DD">
    </div>
    <div class="input">
      <label>Time</label>
      <input type="text" name="fixTime" placeholder="hh-mm-ss">
    </div>
    <div class="input">
      <label>Select Home Team</label>
      <select name='hTeam'>
        <option></option>
        <option value="TEAM A">TEAM A</option>
        <option value="TEAM B">TEAM B</option>
        <option value="TEAM C">TEAM C</option>
        <option value="TEAM D">TEAM D</option>
      </select>
    </div>
    <div class="input">
      <label>Select Away Team</label>
      <select name='aTeam'>
        <option></option>
        <option value="TEAM A">TEAM A</option>
        <option value="TEAM B">TEAM B</option>
        <option value="TEAM C">TEAM C</option>
        <option value="TEAM D">TEAM D</option>
      </select>
    </div>
    <div class="input">
      <label>Select Competition</label>
      <select name='comp'>
        <option></option>
        <option value="COMP A">COMP A</option>
        <option value="COMP B">COMP B</option>
        <option value="COMP C">COMP C</option>
        <option value="COMP D">COMP D</option>
      </select>
    </div>
    <div class="input">
      <button type="Submit" name="submit" class="btn">Submit
      </button>
    </div>
  </form>
  <!--form ends here-->
</body>

</html>