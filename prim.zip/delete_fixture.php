<?php
session_start();
include_once('server.php');
$message = "";
$id = $_GET['fixID'];
if ($id == ""){
header("location:http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/index.php");
exit();
}
if (isset($_POST['submit'])) {
	$fixID = $_POST['fixID'];
	$hTeam = $_POST['hTeam'];
	$aTeam = $_POST['aTeam'];

	$sql = "DELETE FROM fix WHERE fixID = $fixID ";
	mysqli_query($db, $sql);
	header("location:http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/fixtures.php");
	} 
	if(mysqli_connect_error()){
	$message1 = "<font color=red>Update Failed, Try again</font>";
	}
		
?>

<!DOCTYPE html>
<html>

<head>
	<title>Teams</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" media="screen" href="/prim/style.css">
	<meta charset="utf-8">
</head>

<body>
	<h2 class="team">Fixture List</h2>

	<div id="content_1" class="content">
		<?php echo $message; ?>
		<form method="post">
			<table width="420" height="106" border="0">
				<tr>
					<td align="center"><input name="fixID" type="text" readonly style="width:170px" placeholder="fixID" value="<?php include_once('server.php');
																																	echo $_GET['fixID'] ?>" id="fixID" /></td>
				</tr>
				<tr>
					<td align="center"><input name="hTeam" type="text" readonly style="width:170px" placeholder="hTeam" id="hTeam" value="<?php include_once('server.php');
																																	echo $_GET['hTeam'] ?>" id="hTeam"/></td>
				</tr>
				<tr>
					<td align="center"><input name="aTeam" type="text" readonly style="width:170px" placeholder="aTeam" id="aTeam" value="<?php include_once('server.php');
																																	echo $_GET['aTeam'] ?>" id="aTeam"/></td>
				</tr>
				<tr>
					<td align="center"><input name="submit" type="submit" value="Delete" /></td>
				</tr>
			</table>
		</form>
	</div>
</body>

</html>
