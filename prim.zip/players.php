<?php 

session_start();
include('server.php'); 
$message = '';
//if save the submit button is clicked ,information must be submitted
if (isset($_POST['submit'])) {
  $playerName = $_POST['playerName'];
  $playerSurname = $_POST['playerSurname'];
  $playerPosition = $_POST['playerPosition'];
  $shirtNum = $_POST['shirtNum'];
  $team = $_POST['team'];
  // error if user does not enter a Team Name
  if ($playerName == "") {
    $message .= "<p><font color=red>Player name should not be empty</font></p>";
  }
  if ($playerPosition == "") {
    $message .= "<p><font color=red>Player name should not be empty</font></p>";
  }
  if ($shirtNum  == "") {
    $message .= "<p><font color=red>Player name should not be empty</font></p>";
  }
  if ($team == "") {
    $message .= "<p><font color=red>Player name should not be empty</font></p>";
  }
  // error if user does not enter a Team Email
  if ($playerSurname == "") {
    $message .= "<p><font color=red>player surname should not be empty</font></p>";
  } else {

    $query = "SELECT * FROM teams WHERE team_email='$playerName'";
    $sql1 = mysqli_query($db, $query) or die(mysqli_connect_error());
    $result = mysqli_fetch_array($sql1);
    // an Email address can not be entered twice
    if ($result > 0) {
      $message .= "<p><font color=red>sorry the Email Address already exists</font></p>";
    } else {
      $query = "INSERT INTO players(playerName, playerSurname, playerPosition, shirtNum, team) VALUES ('$playerName', '$playerSurname', '$playerPosition', '$shirtNum', '$team')";
      mysqli_query($db, $query);
      // header('location : teametition.php'); //redirect to teametition page
    }
  }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Players</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" media="screen" href="/prim/style.css">
  <meta charset="utf-8">
</head>
<body>
<!--html startst here -->
    <!-- adding my menu starts here-->
    <div class="nav">
    <ul>
      <li><a href="/prim/competition.php/">Competitions</a></li>
      <li><a href="/prim/teams.php">Teams</a></li>
      <li><a href="/prim/fixtures.php">Fixtures</a></li>
      <li><a href="/prim/players.php/">Player lnfo</a></li>
      <li><a href="#">Player Fixtures</a></li>
      <li><a href="#">Reports</a></li>
    </ul>
  </div>
<body>
  <h2 class="headingtitle team">Player Information</h2>
  <div class="error" style="text-align:center"><?php
                                                echo $message;
                                                ?></div>
  <!--View Displays all data from 'Team' table
    -->
  <?php
  // connect to the database
  include_once('server.php');
  // get results from database
  $query = "SELECT * FROM players";
  $result = mysqli_query($db, $query) or die(mysqli_connect_error());
  // display data in table
  echo "<table border='1' cellpadding='5' align='center'>";
  echo "<tr>
      <th>ID</th>
      <th>Player Name </th>
      <th>Surname </th>
      <th>Position</th>
      <th>Shirt Number</th>
      <th>Team </th>
    </tr>";
  // loop through results of database query, displaying them in the table
  while ($row = mysqli_fetch_array($result)) {
    // echo out the contents of each row into a table
    echo "<tr>";
    echo '<td>' . $row['playerID'] . '</td>';
    echo '<td>' . $row['playerName'] . '</td>';
    echo '<td>' . $row['playerSurname'] . '</td>';
    echo '<td>' . $row['playerPosition'] . '</td>';
    echo '<td>' . $row['shirtNum'] . '</td>';
    echo '<td>' . $row['Team'] . '</td>';
    ?>
    <td><a href="/prim/update_player.php?playerID=<?php echo $row['playerID'] ?>"><img src="/prim/images/edit.png" width="25" height="25" border="0" /></a></td>
    <td><a href="/prim/delete_player.php?playerID=<?php echo $row['playerID'].'&playerName='. $row['playerName'] .'&playerSurname='. $row['playerSurname']  ?>"><img src="/prim/images/delete.png" width="25" height="25" border="0" /></a></td>
  <?php
}
// close table>
echo "</table>";
?>
  <!-- form starts here-->
  <!--connection to my database-->
  <form method="post">
    <div class="input">
      <label>Add Player</label>
      <!--<input type="text" name="add Competition">-->
    </div>
    <div class="input">
      <label>Player Name</label>
      <input type="text" name="playerName">
    </div>
    <div class="input">
      <label>Player Surname</label>
      <input type="text" name="playerSurname">
    </div>
    <div class="input">
      <label>Select Team</label>
      <select name="team">
        <option><option>
        <option value="TEAM A">TEAM A</option>
        <option value="TEAM B">TEAM B</option>
        <option value="TEAM C">TEAM C</option>
        <option value="TEAM D">TEAM D</option>
      </select>
    </div>
    <div class="input">
      <label>Number</label>
      <input type="text" name="shirtNum">
    </div>
    <div class="input">
      <label>Position</label><br>
      <input type="radio" value="Goal Keeper" name="playerPosition" > Goal Keeper<br>
      <input type="radio" value="Left Back" name="playerPosition" > Left Back<br>
      <input type="radio" value="left wing back" name="playerPosition" > left wing back<br>
      <input type="radio" value="left wing" name="playerPosition" > left wing<br>
      <input type="radio" value="right wing" name="playerPosition" > right wing<br>
      <input type="radio" value="striker" name="playerPosition" > striker<br>
      <input type="submit" name="submit" value="Submit">
    </div>
  </form>
</body>

</html>