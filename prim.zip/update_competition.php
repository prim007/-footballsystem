<?php
session_start();
include_once('server.php');
$message = "";
$id = $_GET['compID'];
if ($id == ""){
header("location:http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/index.php");
exit();
}
if (isset($_POST['submit'])) {
	$compID = $_POST['compID'];
	$comp = $_POST['comp'];
	// error if user does not enter a comp name
	if ($comp == "") {
		$message .= "<p><font color=red>Competition name should not be empty</font></p>";
	} else {

		$query = "SELECT * FROM teams WHERE comp='$comp'";
		$sql1 = mysqli_query($db, $query) or die(mysqli_connect_error());
		$result = mysqli_fetch_array($sql1);
		// an Email address can not be entered twice
		if ($result > 0) {
			$message .= "<p><font color=red>Sorry competition already exists</font></p>";
		} else {
			$sql = "UPDATE competition SET comp ='$comp' WHERE compID = $compID ";
			mysqli_query($db, $sql);
			header("location:http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/prim/competition.php");
			} 
			
			if(mysqli_connect_error()){
				$message1 = "<font color=red>Update Failed, Try again</font>";
			}
		}
	}
	// Retrieve data from database 
?>
<!DOCTYPE html>
<html>

<head>
	<title>Teams</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" media="screen" href="/prim/style.css">
	<meta charset="utf-8">
</head>

<body>
	<h2 class="team">Update Competition</h2>

	<div id="content_1" class="content">
		<?php echo $message; ?>
		<form method="post">
			<table width="420" height="106" border="0">
				<tr>
					<td align="center"><input name="compID" type="text" readonly style="width:170px" placeholder="compID" value="<?php include_once('server.php');
																																	echo $_GET['compID'] ?>" id="compID" /></td>
				</tr>
				<tr>
					<td align="center"><input name="comp" type="text" style="width:170px" placeholder="competition" id="comp" /></td>
				</tr>
				<tr>
					<td align="center"><input name="submit" type="submit" value="Update" /></td>
				</tr>
			</table>
		</form>
	</div>
</body>

</html>