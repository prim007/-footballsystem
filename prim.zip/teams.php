<?php
session_start();
include_once('server.php');

$message = '';
//if save the submit button is clicked ,information must be submitted
if (isset($_POST['submit'])) {
  $team_name = $_POST['team_name'];
  $team_email = $_POST['team_email'];
  // error if user does not enter a Team Name
  if ($team_name == "") {
    $message .= "<p><font color=red>Email address should not be empty</font></p>";
  }
  // error if user does not enter a Team Email
  if ($team_email == "") {
    $message .= "<p><font color=red>Email address should not be empty</font></p>";
  } else {

    $query = "SELECT * FROM teams WHERE team_email='$team_email'";
    $sql1 = mysqli_query($db, $query) or die(mysqli_connect_error());
    $result = mysqli_fetch_array($sql1);
    // an Email address can not be entered twice
    if ($result > 0) {
      $message .= "<p><font color=red>sorry the Email Address already exists</font></p>";
    } else {
      $query = "INSERT INTO teams(team_name, team_email) VALUES ('$team_name', '$team_email')";
      mysqli_query($db, $query);
      // header('location : teametition.php'); //redirect to teametition page
    }
  }
}
?>

<!DOCTYPE html>
<html>

<head>
  <title>Teams</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" media="screen" href="style.css">
  <meta charset="utf-8">
  <!-- adding my menu starts here-->
  <div class="nav">
    <ul>
      <li><a href="competition.php">Competitions</a></li>
      <li><a href="teams.php">Teams</a></li>
      <li><a href="fixtures.php">Fixtures</a></li>
      <li><a href="players.php">Player lnfo</a></li>
      <li><a href="#">Player Fixtures</a></li>
      <li><a href="#">Reports</a></li>
    </ul>
  </div>
</head>

<body>
  <h2 class="team headingtitle">Teams List</h2>
  <div class="error" style="text-align:center"><?php
                                                echo $message;
                                                ?></div>
  <!--View Displays all data from 'Team' table
    -->
  <?php
  // connect to the database
  include_once('server.php');
  // get results from database
  $query = "SELECT * FROM teams";
  $result = mysqli_query($db, $query) or die(mysqli_connect_error());
  // display data in table
  echo "<table border='1' cellpadding='5' align='center'>";
  echo "<tr>
      <th>ID</th>
      <th>Team Name </th>
      <th>Team Email </th>
      <th>Update </th>
      <th>Delete</th>
    </tr>";
  // loop through results of database query, displaying them in the table
  while ($row = mysqli_fetch_array($result)) {
    // echo out the contents of each row into a table
    echo "<tr>";
    echo '<td>' . $row['teamID'] . '</td>';
    echo '<td>' . $row['team_name'] . '</td>';
    echo '<td>' . $row['team_email'] . '</td>';
    ?>
    <td><a href="update_team.php?teamID=<?php echo $row['teamID'] ?>"><img src="images/edit.png" width="25" height="25" border="0" /></a></td>
    <td><a href="delete_team.php?teamID=<?php echo $row['teamID'].'&team_name='. $row['team_name'] .'&team_email='. $row['team_email'] ?>"><img src="images/delete.png" width="25" height="25" border="0" /></a></td>
  <?php
}
// close table>
echo "</table>";
?>
  <!-- form starts here -->
  <!-- connection to my database -->
  <form method="post">
    <div class="input">
      <h3> ADD TEAM </h3>
    </div>
    <div class="input">
      <label>Team Name </label>
      <input type="text" name="team_name">
    </div>
    <div class="input">
      <label>Team Email </label>
      <input type="text" name="team_email">
    </div>
    <div class="input">
      <input type="submit" value="submit" name="submit">
    </div>
  </form>
  <!--form ends here-->
</body>

</html>