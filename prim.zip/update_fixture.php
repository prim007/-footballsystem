<?php
session_start();
include_once('server.php');
$message = "";
if ($id = $_SESSION['fixID']){
header("location:http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/index.php");
exit();
}
if (isset($_POST['submit'])) {
	$fixID = $_POST['fixID'];
	$hTeam = $_POST['hTeam'];
	$aTeam = $_POST['aTeam'];
	$fixDate = $_POST['fixDate'];
	$fixTime = $_POST['fixTime'];
    $comp = $_POST['comp'];
	// error if user does not enter a Team Name
	if ($aTeam == "") {
		$message .= "<p><font color=red>Team Name should not be empty</font></p>";
	}
	// error if user does not enter a Team Email
	if ($hTeam == "") {
		$message .= "<p><font color=red>Team Email should not be empty</font></p>";
	} else {

		$query = "SELECT * FROM teams WHERE hTeam='$hTeam'";
		$sql1 = mysqli_query($db, $query) or die(mysqli_connect_error());
		$result = mysqli_fetch_array($sql1);
		// an Email address can not be entered twice
		if ($result > 0) {
			$message .= "<p><font color=red>Sorry the Email Address already exists</font></p>";
		} else {
			$sql = "UPDATE fix SET aTeam='$aTeam', hTeam='$hTeam' fixDate='$fixDate', fixTime='$fixTime', comp ='$comp' WHERE fixID = $fixID ";
			mysqli_query($db, $sql);
			header("location:http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/fixtures.php");
			} 
			
			if(mysqli_connect_error()){
				$message1 = "<font color=red>Update Failed, Try again</font>";
			}
		}
	}
	// Retrieve data from database 
?>
<!DOCTYPE html>
<html>

<head>
	<title>Teams</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" media="screen" href="/prim/style.css">
	<meta charset="utf-8">
</head>

<body>
	<h2 class="team">Fixture List</h2>

	<div id="content_1" class="content">
		<?php echo $message; ?>
		<form method="post">
			<div class="input">
			<label>ID</label>
<input name="fixID" type="text" readonly style="width:170px" placeholder="fixID" value="<?php include_once('server.php');
																																	echo $_GET['fixID'] ?>" id="fixID" />
    </div>
    <div class="input">
      
      <input type="text" name="fixDate" placeholder="YYYY-MM-DD">
    </div>
    <div class="input">
      <label>Time</label>
      <input type="text" name="fixTime" placeholder="hh-mm-ss">
    </div>
    <div class="input">
      <label>Select Home Team</label>
      <select name='hTeam'>
        <option></option>
        <option value="TEAM A">TEAM A</option>
        <option value="TEAM B">TEAM B</option>
        <option value="TEAM C">TEAM C</option>
        <option value="TEAM D">TEAM D</option>
      </select>
    </div>
    <div class="input">
      <label>Select Away Team</label>
      <select name='aTeam'>
        <option></option>
        <option value="TEAM A">TEAM A</option>
        <option value="TEAM B">TEAM B</option>
        <option value="TEAM C">TEAM C</option>
        <option value="TEAM D">TEAM D</option>
      </select>
    </div>
    <div class="input">
      <label>Select Competition</label>
      <select name='comp'>
        <option></option>
        <option value="COMP A">COMP A</option>
        <option value="COMP B">COMP B</option>
        <option value="COMP C">COMP C</option>
        <option value="COMP D">COMP D</option>
      </select>
    </div>
    <div class="input">
      <button type="Submit" name="submit" class="btn">Submit
      </button>
    </div>
  </form>
	</div>
</body>

</html>