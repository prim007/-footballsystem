<?php
session_start();
include_once('server.php');
$message = "";
$id = $_GET['compID'];
if ($id == ""){
header("location:http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/index.php");
exit();
}
if (isset($_POST['submit'])) {
	$compID = $_POST['compID'];
	$comp = $_POST['comp'];

	$sql = "DELETE FROM competition WHERE compID = $compID ";
	mysqli_query($db, $sql);
	header("location:http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/competition.php");
	} 
	if(mysqli_connect_error()){
	$message1 = "<font color=red>Update Failed, Try again</font>";
	}
		
?>

<!DOCTYPE html>
<html>

<head>
	<title>Teams</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" media="screen" href="/prim/style.css">
	<meta charset="utf-8">
</head>

<body>
	<h2 class="team">Teams List</h2>

	<div id="content_1" class="content">
		<?php echo $message; ?>
		<form method="post">
			<table width="420" height="106" border="0">
				<tr>
					<td align="center"><input name="compID" type="text" readonly style="width:170px" placeholder="compID" value="<?php include_once('server.php');
																																	echo $_GET['compID'] ?>" id="compID" /></td>
				</tr>

				<tr>
					<td align="center"><input name="comp" type="text" readonly style="width:170px" placeholder="Competition" id="comp" value="<?php include_once('server.php');
																																	echo $_GET['comp'] ?>" id="comp"/></td>
				</tr>
				<tr>
					<td align="center"><input name="submit" type="submit" value="Delete" /></td>
				</tr>
			</table>
		</form>
	</div>
</body>

</html>
