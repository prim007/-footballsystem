<?php
session_start();
include_once('server.php');
$message = "";
$id = $_GET['playerID'];
if ($id ==""){
header("location:http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/index.php");
exit();
}
if (isset($_POST['submit'])) {
	$playerID = $_POST['playerID'];
	$playerName = $_POST['playerName'];
	$playerSurname = $_POST['playerSurname'];
	$playerPosition = $_POST['playerPosition'];
	$shirtNum = $_POST['shirtNum'];
	$team = $_POST['team'];
	// error if user does not enter a Team Name
	if ($playerSurname == "") {
		$message .= "<p><font color=red>Team Name should not be empty</font></p>";
	}
	// error if user does not enter a Team Email
	if ($playerName == "") {
		$message .= "<p><font color=red>Team Email should not be empty</font></p>";
	} else {

		$query = "SELECT * FROM teams WHERE playerName='$playerName'";
		$sql1 = mysqli_query($db, $query) or die(mysqli_connect_error());
		$result = mysqli_fetch_array($sql1);
		// an Email address can not be entered twice
		if ($result > 0) {
			$message .= "<p><font color=red>Sorry the Email Address already exists</font></p>";
		} else {
			$sql = "UPDATE players SET playerSurname='$playerSurname', playerName='$playerName', playerPosition='$playerPosition', shirtNum='$shirtNum', team='$team' WHERE playerID = $playerID ";
			mysqli_query($db, $sql);
			header("location:http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/players.php");
			} 
			
			if(mysqli_connect_error()){
				$message1 = "<font color=red>Update Failed, Try again</font>";
			}
		}
	}
	// Retrieve data from database 
?>
<!DOCTYPE html>
<html>

<head>
	<title>Teams</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" media="screen" href="/prim/style.css">
	<meta charset="utf-8">
</head>

<body>
	<h2 class="team">Update Player</h2>

	<div id="content_1" class="content">
		<?php echo $message; ?>
		<form method="post">
		<div class="input">
			<label>ID</label>
<input name="playerID" type="text" readonly style="width:170px" placeholder="playerID" value="<?php include_once('server.php');
																																	echo $_GET['playerID'] ?>" id="playerID" />
																																	</div>
				<form method="post">
    <div class="input">
      <label>Add Player</label>
      <!--<input type="text" name="add Competition">-->
    </div>
    <div class="input">
      <label>Player Name</label>
      <input type="text" name="playerName">
    </div>
    <div class="input">
      <label>Player Surname</label>
      <input type="text" name="playerSurname">
    </div>
    <div class="input">
      <label>Select Team</label>
      <select name="team">
        <option><option>
        <option value="TEAM A">TEAM A</option>
        <option value="TEAM B">TEAM B</option>
        <option value="TEAM C">TEAM C</option>
        <option value="TEAM D">TEAM D</option>
      </select>
    </div>
    <div class="input">
      <label>Number</label>
      <input type="text" name="shirtNum">
    </div>
    <div class="input">
      <label>Position</label><br>
      <input type="radio" value="Goal Keeper" name="playerPosition" > Goal Keeper<br>
      <input type="radio" value="Left Back" name="playerPosition" > Left Back<br>
      <input type="radio" value="left wing back" name="playerPosition" > left wing back<br>
      <input type="radio" value="left wing" name="playerPosition" > left wing<br>
      <input type="radio" value="right wing" name="playerPosition" > right wing<br>
      <input type="radio" value="striker" name="playerPosition" > striker<br>
      <input type="submit" name="submit" value="Submit">
    </div>
  </form>
	</div>
</body>

</html>