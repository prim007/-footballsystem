<?php
session_start();
include_once('server.php');
$message = "";
if ($id = $_SESSION['teamID']){
header("location:http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/index.php");
exit();
}
if (isset($_POST['submit'])) {
	$teamID = $_POST['teamID'];
	$team_email = $_POST['team_email'];
	$team_name = $_POST['team_name'];

	$sql = "DELETE FROM teams WHERE teamID = $teamID ";
	mysqli_query($db, $sql);
	header("location:http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/teams.php");
	} 
	if(mysqli_connect_error()){
	$message1 = "<font color=red>Update Failed, Try again</font>";
	}
		
?>

<!DOCTYPE html>
<html>

<head>
	<title>Teams</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" media="screen" href="/prim/style.css">
	<meta charset="utf-8">
</head>

<body>
	<h2 class="team">Teams List</h2>

	<div id="content_1" class="content">
		<?php echo $message; ?>
		<form method="post">
			<table width="420" height="106" border="0">
				<tr>
					<td align="center"><input name="teamID" type="text" readonly style="width:170px" placeholder="teamID" value="<?php include_once('server.php');
																																	echo $_GET['teamID'] ?>" id="teamID" /></td>
				</tr>
				<tr>
					<td align="center"><input name="team_name" type="text" readonly style="width:170px" placeholder="Team Name" id="team_name" value="<?php include_once('server.php');
																																	echo $_GET['team_name'] ?>" id="team_name"/></td>
				</tr>
				<tr>
					<td align="center"><input name="team_email" type="text" readonly style="width:170px" placeholder="Team Email" id="team_email" value="<?php include_once('server.php');
																																	echo $_GET['team_email'] ?>" id="team_email"/></td>
				</tr>
				<tr>
					<td align="center"><input name="submit" type="submit" value="Delete" /></td>
				</tr>
			</table>
		</form>
	</div>
</body>

</html>
