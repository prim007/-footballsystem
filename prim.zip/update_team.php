<?php
session_start();
include_once('server.php');
$message = "";
if ($id = $_SESSION['teamID']){
header("location:http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/index.php");
exit();
}
if (isset($_POST['submit'])) {
	$teamID = $_POST['teamID'];
	$team_email = $_POST['team_email'];
	$team_name = $_POST['team_name'];
	// error if user does not enter a Team Name
	if ($team_name == "") {
		$message .= "<p><font color=red>Team Name should not be empty</font></p>";
	}
	// error if user does not enter a Team Email
	if ($team_email == "") {
		$message .= "<p><font color=red>Team Email should not be empty</font></p>";
	} else {

		$query = "SELECT * FROM teams WHERE team_email='$team_email'";
		$sql1 = mysqli_query($db, $query) or die(mysqli_connect_error());
		$result = mysqli_fetch_array($sql1);
		// an Email address can not be entered twice
		if ($result > 0) {
			$message .= "<p><font color=red>Sorry the Email Address already exists</font></p>";
		} else {
			$sql = "UPDATE teams SET team_name='$team_name', team_email='$team_email' WHERE teamID = $teamID ";
			mysqli_query($db, $sql);
			header("location:http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/teams.php");
			} 
			
			if(mysqli_connect_error()){
				$message1 = "<font color=red>Update Failed, Try again</font>";
			}
		}
	}
	// Retrieve data from database 
?>
<!DOCTYPE html>
<html>

<head>
	<title>Teams</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" media="screen" href="/prim/style.css">
	<meta charset="utf-8">
</head>

<body>
	<h2 class="team">Teams List</h2>

	<div id="content_1" class="content">
		<?php echo $message; ?>
		<form method="post">
			<table width="420" height="106" border="0">
				<tr>
					<td align="center"><input name="teamID" type="text" readonly style="width:170px" placeholder="teamID" value="<?php include_once('server.php');
																																	echo $_GET['teamID'] ?>" id="teamID" /></td>
				</tr>
				<tr>
					<td align="center"><input name="team_name" type="text" style="width:170px" placeholder="Team Name" id="team_name" /></td>
				</tr>
				<tr>
					<td align="center"><input name="team_email" type="text" style="width:170px" placeholder="Team Email" id="team_email" /></td>
				</tr>
				<tr>
					<td align="center"><input name="submit" type="submit" value="Update" /></td>
				</tr>
			</table>
		</form>
	</div>
</body>

</html>