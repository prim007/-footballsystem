<?php

  $comp_name = "";
  $comp_id = 0;
//connecting to the database
$db = mysqli_connect('localhost', 'root', '', 'fms');

//if (mysqli_connect_error()) {
 // die("There was an error connecting to the database");
//} 

?>
