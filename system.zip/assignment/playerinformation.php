<?php include('server.php');?>

<!DOCTYPE html>
  <html>
  <head>
    <title>Player Information</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--<link rel="stylesheet" type="text/css" media="screen" href="style.css">-->
    <meta charset="utf-8">
  </head>
<!--css-->
<style>
  .headingtitle{
    text-align: center;
    font-size: 50px;
  }
  table{
  background-color: #ccc;
  width: 40%;

  }

  form{
    width: 37%;
    margin-top: 15px;
    text-align: left;
    border: 1px solid #000;
    border-radius: 5px;
    padding: 24px;
    position: absolute;
    left: 30%;
  }

 .input {
   margin: 10px 0px 10px 0px;
 }

  .input label {
    display: block;
    text-align: left;
    margin: 3px;
  }

  .input input {
    height: 30px;
    width: 225px;
    padding:5px 10px;
    font-size: 16px;
    border: 1px solid #000;
    }

    .btn {
      padding: 10px;
      font-size: 15px;
      color: #fff;
      background: #663366;
      border: none;
      border-radius: 5px;
    }

  th {
  text-align: left;
  }

  table,th,td {
    /*border:1px solid #000;*/
    border-collapse: collapse;
}

h2 {
  text-align: center;
  font-size: 50px;
}
</style>
<!--html startst here -->
  <body>
<h2 class="team">Player Information</h2>
<!--table starts here-->
<table align = "center">
    <tr>
      <th>Player<th>
      <th>Team<th>
      <th>Shirt Number<th>
      <th>Position<th>
      <th>Actions<th>
    </tr>
    <tr>
      <td>Name<td>
      <td><a href="">X</a></td>
      <td><a href="#">12</a></td>
      <td><a href="#">GK</a></td>
      <td><a href="#">Edit</a></td>
      <td><a href="#">Delete</a></td>
    </tr>
    <tr>
      <td>Name2<td>
      <td><a href="">Y</a></td>
      <td><a href="#">23</a></td>
      <td><a href="#">CB</a></td>
      <td><a href="#">Edit</a></td>
      <td><a href="#">Delete</a></td>
    </tr>
  </table>
    <!--table ends here-->
<!-- form starts here-->
<!--connection to my database-->
<form>
  <div class="input">
    <label>Add Player</label>
    <!--<input type="text" name="add Competition">-->
  </div>
  <div class="input">
    <label>Surname Name</label>
    <input type="text" name="add Competition">
  </div>
  <div class="input">
    <label>Select Team</label>
<select>
  <option value="volvo">TEAM A</option>
  <option value="saab">TEAM B</option>
  <option value="mercedes">TEAM C</option>
  <option value="audi">TEAM D</option>
</select>
</div>
  <div class="input">
    <label>Number</label>
    <input type="text" name="add Competition">
  </div>
  <div class="input">
    <label>Position</label>
    <input type="radio" name="gender" value="male"> GK<br>
    <input type="radio" name="gender" value="female"> LB<br>
    <input type="radio" name="gender" value="other"> lwb<br>  
    <input type="submit" value="Submit">
  </div>

  <div class="input">
    <button type="Submit" name="submit" class="btn">Submit
    </button>
  </div>
</form>
<!--form ends here-->
  </body>
</html>
