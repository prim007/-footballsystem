--------------------------------------------------------------------------<?php include('server.php');?>

<!DOCTYPE html>
  <html>
  <head>
    <title>Teams</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--<link rel="stylesheet" type="text/css" media="screen" href="style.css">-->
    <meta charset="utf-8">
  </head>

<style>
  .headingtitle{
    text-align: center;
    font-size: 50px;
  }
  table{
  background-color: #ccc;
  width: 40%;

  }

  form{
    width: 37%;
    margin-top: 15px;
    text-align: left;
    border: 1px solid #000;
    border-radius: 5px;
    padding: 24px;
    position: absolute;
    left: 30%;
  }

 .input {
   margin: 10px 0px 10px 0px;
 }

  .input label {
    display: block;
    text-align: left;
    margin: 3px;
  }

  .input input {
    height: 30px;
    width: 225px;
    padding:5px 10px;
    font-size: 16px;
    border: 1px solid #000;
    }

    .btn {
      padding: 10px;
      font-size: 15px;
      color: #fff;
      background: #663366;
      border: none;
      border-radius: 5px;
    }

  th {
  text-align: left;
  }

  table,th,td {
    /*border:1px solid #000;*/
    border-collapse: collapse;
}

h2 {
  text-align: center;
  font-size: 50px;
}
</style>

  <body>
<h2 class="team">Teams List</h2>
<!--table starts here-->
<table align = "center">
    <tr>
      <th>Teams<th>
      <th>Team Email<th>
      <th>Actions<th>
    </tr>
    <tr>
      <td>Bafana Bafana<td>
      <td><a href="">bafanabafana@gmail.com</a></td>
      <td><a href="#">Edit</a></td>
      <td><a href="#">Delete</a></td>
    </tr>
    <tr>
      <td>Chelsea<td>
      <td><a href="">bafanabafana@gmail.com</a></td>
      <td><a href="#">Edit</a></td>
      <td><a href="#">Delete</a></td>
    </tr>
    <tr>
      <td>Cricket<td>
      <td><a href="">bafanabafana@gmail.com</a></td>
      <td><a href="#">Edit</a></td>
      <td><a href="#">Delete</a></td>
    </tr>
    <tr>
      <td>Netball<td>
      <td><a href="">bafanabafana@gmail.com</a></td>
      <td><a href="#">Edit</a></td>
      <td><a href="#">Delete</a></td>
    </tr>
    <tr>
      <td>Basketball<td>
      <td><a href="">bafanabafana@gmail.com</a></td>
      <td><a href="#">Edit</a></td>
      <td><a href="#">Delete</a></td>
    </tr>
      </table>
    <!--table ends here-->
<!-- form starts here-->
<!--connection to my database-->
<form>
  <div class="input">
    <label>Add Team</label>
    <input type="text" name="add Competition">
  </div>
  <div class="input">
    <label>Team</label>
    <input type="text" name="add Competition">
  </div>
  <div class="input">
    <label>Team Email</label>
    <input type="text" name="add Competition">
  </div>
  <div class="input">
    <button type="Submit" name="submit" class="btn">Submit
    </button>
  </div>
</form>
<!--form ends here-->
  </body>
</html>
