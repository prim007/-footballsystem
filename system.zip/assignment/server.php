<?php

  $comp_name = "";
  $comp_id = 0;
//connecting to the database
$db = mysqli_connect('localhost', 'root', 'importantdatabase');

//if save the submit button is clicked ,information must be submitted
if(isset($_POST['submit'])) {
  $comp_name = $_POST['comp_name'];
  $comp_id = $_POST['comp_id'];
  $query = "INSERT INTO importantdatabase (comp_name) VALUES ('$comp_name')";
  mysqli_query($db,$query);
  header('location : competition.php'); //redirect to competition page
  }

?>
