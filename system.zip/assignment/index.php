<!DOCTYPE html>

<html>
  <head>
      <title>Football Management System</title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" media="screen" href="style.css">
      <meta charset="utf-8">
</head>
<body>
  <!-- adding my menu starts here-->
<div class="nav">
     <ul>
         <li><a href="http://localhost/assignment/competition.php/">Competitions</a></li>
         <li><a href="http://localhost/assignment/teams.php">Teams</a></li>
         <li><a href="http://localhost/assignment/fixtures.php">Fixtures</a></li>
         <li><a href="http://localhost/assignment/positions.php/">Player Positions</a></li>
         <li><a href="http://localhost/assignment/playerinformation.php/">Players lnformation</a></li>
         <li><a href="#">Player Fixtures</a></li>
         <li><a href="#">Reports</a></li>
     </ul>
    </div>
    <!--menu ends here-->
    <!--img and text-->
   <div class="img">
      <h2 class="header">Welcome to Football Management System.<br>Your World best place to get the latest football results</h2>
   </div>
   <!--ends here-->
</body>
</html>
